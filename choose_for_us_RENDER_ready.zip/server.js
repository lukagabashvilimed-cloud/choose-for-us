const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

const choices = new Map();

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/choose", (req,res)=>{
  const { room, movie } = req.body || {};
  if(!room || !movie) return res.status(400).json({error:"room and movie required"});
  choices.set(room.toUpperCase(), { movie, chosenAt: Date.now() });
  res.json({ok:true});
});

app.get("/api/choice/:room", (req,res)=>{
  res.json(choices.get(req.params.room.toUpperCase()) || null);
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log("Choose for Us running on "+PORT));
