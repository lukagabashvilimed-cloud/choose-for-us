# Choose for Us ❤️ — Render-ready

## Deploy to Render
1. Create a GitHub repository and upload these files.
2. In Render, create a new **Web Service** from that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Choose a free/paid instance as desired.
6. Render will give you a public `https://...` URL.

## Note
This starter version stores choices in server memory, so a restart/deploy can clear them.
For a permanent production version, replace the in-memory Map with a hosted database such as Supabase.
